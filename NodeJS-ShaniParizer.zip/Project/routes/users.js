const express = require("express");
const _ = require("lodash");
const bcrypt = require("bcrypt");
const { User, validate, validateCards } = require("../models/user"); //Import the validation by mongoose and JOI
const { Card } = require("../models/card");
const router = express.Router(); //Creation ROUTER method - it is a class router insider thr express to route the data
const auth = require("../middleware/auth");

router.get("/me", auth, async (req, res) => {
  const user = await User.findById(req.user._id).select("-password");
  res.send(user);
});

//The responde of the error in the validation of JOI
router.post("/", async (req, res) => {
  const { error } = validate(req.body);
  if (error) return res.status(400).send(error.details[0].message);

  //Verification of no double emails

  let user = await User.findOne({ email: req.body.email });
  if (user) return res.status(400).send("This email already in use");
  // Create the user object from the model class
  user = new User(
    _.pick(req.body, ["name", "email", "password", "biz", "cards"])
  );

  const salt = await bcrypt.genSalt(10); //Preprocesing and rounds
  user.password = await bcrypt.hash(user.password, salt); //Encryption
  await user.save(); //Saving
  res.send(_.pick(user, ["_id", "name", "email"])); //Return details of the user and send back the inserted user picked fields by LODASH
});

const getCards = async (cardsArray) => {
  let cards = await Card.find({ bizNumber: { $in: cardsArray } });
  return cards;
};

router.get("/cards", auth, async (req, res) => {
  //Check that we have a query string with number
  if (!req.query.numbers)
    return res.status(400).send("Cards number are missing");
  //create cards array with the biz numbers
  let data = {};
  data.cards = req.query.numbers.split(",");
  //Get an array with the cards documents as objects
  const cards = await getCards(data.cards);
  //Send the cards arrayto the client
  res.send(cards);
});

router.patch("/cards", auth, async (req, res) => {
  //validity check

  const { error } = validateCards(req.body);
  if (error) return res.status(400).send(error.details[0].message);

  //Get an array with all the cards by their bizNumbers
  let cards = await getCards(req.body.cards);

  //Check that both arrays length are identical
  if (cards.length != req.body.cards.length)
    return res.status(400).send("Cards numbers don't match");
  //Update the cards field in the object
  let user = await User.findById(req.user._id);
  user.cards = req.body.cards;
  //Save the new user object
  user.save();
  //Send the result to the client
  res.send(user);
});

module.exports = router;
