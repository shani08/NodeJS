const Joi = require("Joi");
const { User } = require("../models/user"); //Ask dani if the order here is important????
const bcrypt = require("bcrypt");
const express = require("express");
const router = express.Router();

router.post("/", async (req, res) => {
  //Validate data by Joi
  const { error } = validateSignIn(req.body);
  if (error) return res.status(400).send(error.details[0].message);

  //Check if data exists
  let user = await User.findOne({ email: req.body.email });
  if (!user) return res.status(400).send("Invalid Email or password");

  //Check if the password is correct
  const validPassword = await bcrypt.compare(req.body.password, user.password); //We added "AWAIT", not in the sliders part two
  if (!validPassword) return res.status(400).send("Invalid Email or password");

  //Pass to the auth middleware

  res.json({ token: user.generateAuthToken() });
});

function validateSignIn(data) {
  const schema = Joi.object({
    email: Joi.string().min(6).max(255).email().required(),
    password: Joi.string().min(6).max(255).required(),
  });
  return schema.validate(data);
}

module.exports = router;
