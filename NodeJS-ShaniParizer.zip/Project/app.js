//First side
const auth = require("./routes/auth");
const cards = require("./routes/cards");
const users = require("./routes/users");
const db = require("./db/db");
//Second side
const express = require("express");
const app = express();
const http = require("http").Server(app); //Ask what does it mean???? Do we have to install it? Creating server and bring app to it...
//Third side

const { required } = require("joi");

app.use(express.json());
app.use("/api/auth", auth); //Routes the authntication
app.use("/api/users", users); //Routes the endpoint
app.use("/api/cards", cards); //Routes the cards

const port = process.env.PORT || 3000; //Process.env.PORT -  means to the default in your computer(doesn't default in my computer)

//Reastrting our server

http.listen(port, () =>
  console.log(`Listening to port ${port}, click http://localhost:${port}`)
);
