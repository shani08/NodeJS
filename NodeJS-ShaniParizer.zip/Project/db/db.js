const mongoose = require("mongoose");

//Connection to mongoose
const db = mongoose
  .connect("mongodb://localhost:27017/my_project", {
    useNewUrlParser: true, //We have to do it to connect to the MongoDB
    useUnifiedTopology: true, //We have to do it to connect to the MongoDB
    useCreateIndex: true,
  })
  .then(() => console.log("Connected to MongoDB..."))
  .catch((err) => console.log("Unable to connect MongoDB..." + err));

module.exports = db;
